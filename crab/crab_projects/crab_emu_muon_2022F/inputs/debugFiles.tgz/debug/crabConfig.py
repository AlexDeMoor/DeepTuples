from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'crab_projects'
config.General.requestName = 'emu_muon_2022F'
config.General.transferLogs = True
config.section_('JobType')
config.JobType.allowUndistributedCMSSW = True
config.JobType.psetName = '../DeepNtuplizer/production/DeepNtuplizer_emu.py'
config.JobType.pluginName = 'Analysis'
config.JobType.maxMemoryMB = 2500
config.JobType.numCores = 1
config.JobType.maxJobRuntimeMin = 2750
config.section_('Data')
config.Data.inputDataset = '/Muon/Run2022F-22Sep2023-v2/MINIAOD'
config.Data.outLFNDirBase = '/store/group/phys_btag/ParT_2024/Data_samples_nom/emu/2022F'
config.Data.publishDBS = 'phys03'
config.Data.ignoreLocality = False
config.Data.outputDatasetTag = 'part_2024'
config.Data.unitsPerJob = 50
config.Data.splitting = 'LumiBased'
config.Data.lumiMask = '../json/Cert_Collisions2022_355100_362760_Golden.json'
config.Data.inputDBS = 'global'
config.section_('Site')
config.Site.storageSite = 'T2_CH_CERN'
config.Site.whitelist = ['T2_*', 'T3_*']
config.Site.blacklist = ['T2_BR_UERJ']
config.section_('User')
config.section_('Debug')
config.Debug.extraJDL = ['+CMS_ALLOW_OVERFLOW=False']
